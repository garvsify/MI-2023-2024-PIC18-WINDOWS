#ifndef CONFIG_BITS_H
#define	CONFIG_BITS_H

#include "/Users/jamesgarvey/Documents/Git/MI-2023_2024-PIC18/system_uC.h"
#include <xc.h>

#endif
