#ifndef SYSTEM_H
#define	SYSTEM_H

#include <xc.h>
#include "/Users/jamesgarvey/Documents/Git/MI-2023_2024-PIC18/system_uC.h"

uint8_t SYSTEM_Initialize(void);

#endif